module.exports = {
    theme: {
      extend: {
        colors: {
          customGray: 'rgb(31, 37, 50)',
        },
      },
    },
    plugins: [],
  }